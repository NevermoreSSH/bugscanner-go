package main

import "github.com/aztecrabbit/bugscanner-go/cmd"

func main() {
	cmd.Execute()
}
